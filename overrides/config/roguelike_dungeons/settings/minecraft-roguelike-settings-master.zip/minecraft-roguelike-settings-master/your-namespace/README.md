Copy and rename this folder to your personal namespace (e.g. handle, alias) and put any of your custom settings in here.

You can create arbitrary directories here to sort settings `.json` files by concern, e.g. `loot/`, `dungeon/`, or `spawners/`.

This will make retaining and updating your custom settings easier as the settings pack updates and changes.
